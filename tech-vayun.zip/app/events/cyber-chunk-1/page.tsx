import EventPage from '@/components/event-page'

export default function CyberChunk1Page() {
  return (
    <EventPage
      title="CYBER CHUNK 1.0"
      description="Mr.Parthivamudikar, a threat researcher (Microsoft threat expert team) shared their wealth of knowledge, offering invaluable insights into the latest cybersecurity trends and diverse career paths within the field. Through interactive sessions, participants got to explore the details of cybersecurity through engaging presentations and interactive discussions, gaining practical knowledge for real-world scenarios."
      images={['/placeholder.svg?height=400&width=600']}
    />
  )
}

