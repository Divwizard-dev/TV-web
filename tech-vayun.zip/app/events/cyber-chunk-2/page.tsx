import EventPage from '@/components/event-page'

export default function CyberChunk2Page() {
  return (
    <EventPage
      title="CYBER CHUNK 2.0"
      description="Attendees gained exclusive insights into the future of cybersecurity with Puneet Khandelwal, exploring emerging trends and new job opportunities in the field. The event provided a pivotal platform for professionals and enthusiasts to expand their knowledge and explore cutting-edge technologies. Stay tuned for more updates on upcoming events that delve into the intersection of technology and security!"
      images={['/placeholder.svg?height=400&width=600']}
    />
  )
}

