import EventPage from '@/components/event-page'

export default function PhantomShotsPage() {
  return (
    <EventPage
      title="PHANTOM SHOTS"
      description="It was a photoshop and ethical hacking sessions conducted from 1st june 2020 to 3rd june 2020 to 12th and final year diploma students. The event aimed to share knowledge, experiences and facts on photoshops and ethical hacking. E-certificates were provided to all the participants, making this event successful!"
      images={['/placeholder.svg?height=400&width=600']}
    />
  )
}

