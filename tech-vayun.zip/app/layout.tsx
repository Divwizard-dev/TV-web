import React from 'react'
import type { Metadata } from 'next'
import Link from 'next/link'
import { Inter } from 'next/font/google'
import './globals.css'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'Tech Vayuna',
  description: 'Tech Vayuna - Technology Community',
}

const navLinks = [
  { href: "/about-us", text: "ABOUT US" },
  { href: "/events", text: "EVENTS" },
  { href: "/our-team", text: "OUR TEAM" },
  { href: "/contact", text: "CONTACT" },
  { href: "/join-us", text: "JOIN US!" },
]

const footerLinks = [
  { title: "Menu", links: [
    { href: "/", text: "Home" },
    { href: "/about-us", text: "About Us" },
    { href: "/our-team", text: "Our Team" },
    { href: "/events", text: "Events" },
  ]},
  { title: "Contact", links: [
    { href: "/email", text: "Email" },
    { href: "/linkedin", text: "LinkedIn" },
    { href: "/instagram", text: "Instagram" },
    { href: "/twitter", text: "Twitter" },
  ]},
]

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <div className="min-h-screen bg-gradient-to-br from-[#0B1B44] via-[#241B44] to-[#0B1B44]">
          <header className="px-6 py-4 flex items-center justify-between">
            <Link href="/" className="flex items-center">
              <img 
                src="/logo.svg" 
                alt="Tech Vayuna" 
                className="h-12"
              />
            </Link>
            <nav className="flex gap-8">
              {navLinks.map((link, index) => (
                <Link key={index} href={link.href} className="text-white hover:text-gray-300">
                  {link.text}
                </Link>
              ))}
            </nav>
          </header>
          <main>
            {children}
          </main>
          <footer className="px-6 py-8 text-white">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {footerLinks.map((section, index) => (
                <div key={index}>
                  <h3 className="font-bold mb-4">{section.title}</h3>
                  <div className="flex flex-col gap-2">
                    {section.links.map((link, linkIndex) => (
                      <Link key={linkIndex} href={link.href} className="hover:text-gray-300">
                        {link.text}
                      </Link>
                    ))}
                  </div>
                </div>
              ))}
              <div>
                <h3 className="font-bold mb-4">Address</h3>
                <p className="text-sm">
                  SRM Institute Of Science And Technology<br />
                  Bharathi Salai, Ramapuram, Chennai,<br />
                  Tamil Nadu 600089
                </p>
              </div>
            </div>
          </footer>
        </div>
      </body>
    </html>
  )
}

