'use client'

import React from 'react'
import { motion } from 'framer-motion'
import Link from 'next/link'

interface FeaturedEventProps {
  title: string
  description: string
  link: string
}

export default function FeaturedEvent({ title, description, link }: FeaturedEventProps) {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="bg-white/10 p-6 rounded-lg shadow-lg"
    >
      <h2 className="text-2xl font-bold text-white mb-4">{title}</h2>
      <p className="text-gray-300 mb-4">{description}</p>
      <Link href={link}>
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className="bg-purple-600 hover:bg-purple-700 text-white font-bold py-2 px-4 rounded"
        >
          Learn More
        </motion.button>
      </Link>
    </motion.div>
  )
}

