import React from 'react'
import Link from 'next/link'

interface EventCardProps {
  title: string
  href: string
  description: string
}

const EventCard: React.FC<EventCardProps> = ({ title, href, description }) => {
  return (
    <Link href={href}>
      <div className="p-6 rounded-lg bg-white/5 hover:bg-white/10 transition-colors">
        <h2 className="text-2xl font-bold text-white mb-2">{title}</h2>
        <p className="text-gray-300">{description}</p>
      </div>
    </Link>
  )
}

export default EventCard

