'use client'

import React, { useState } from 'react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import Image from "next/image"

interface EventPageProps {
  title: string
  description: string
  images: string[]
}

export default function EventPage({ title, description, images }: EventPageProps) {
  const [email, setEmail] = useState('')
  const [submitted, setSubmitted] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Here you would typically send the email to your backend
    console.log('Submitted email:', email)
    setSubmitted(true)
  }

  return (
    <div className="container mx-auto px-6 py-12">
      <h1 className="text-4xl font-bold text-white text-center mb-12">{title}</h1>
      <div className="flex flex-col lg:flex-row gap-12">
        <div className="w-full lg:w-1/3 space-y-4">
          {images.map((image, index) => (
            <div key={index} className="relative h-48 w-full">
              <Image
                src={image}
                alt={`Event image ${index + 1}`}
                fill
                className="object-cover rounded-lg"
              />
            </div>
          ))}
        </div>
        <div className="w-full lg:w-2/3 text-white">
          <p className="text-lg mb-12 leading-relaxed">
            {description}
          </p>
          <div className="h-px bg-orange-500 w-24 mb-8" />
          <h2 className="text-2xl mb-8">date time speakers</h2>
          {!submitted ? (
            <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-4 items-start sm:items-center">
              <Input 
                type="email" 
                placeholder="Email" 
                className="w-full sm:w-64 bg-transparent border-white/20"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
              <Button 
                type="submit"
                className="w-full sm:w-auto bg-purple-600 hover:bg-purple-700 text-white"
              >
                SUBMIT
              </Button>
            </form>
          ) : (
            <p className="text-green-400">Thank you for your submission!</p>
          )}
        </div>
      </div>
    </div>
  )
}

